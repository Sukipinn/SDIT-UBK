@echo off
echo ======================================== > ALL_CODE_COMPLETE.txt
echo SDIT UBK7 - COMPLETE CODE COMPILATION >> ALL_CODE_COMPLETE.txt
echo Generated: %date% %time% >> ALL_CODE_COMPLETE.txt
echo ======================================== >> ALL_CODE_COMPLETE.txt
echo. >> ALL_CODE_COMPLETE.txt

echo Compiling all code files...

REM API Files
for /r api %%f in (*.php) do (
    echo. >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    echo FILE: %%f >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    type "%%f" >> ALL_CODE_COMPLETE.txt
)

REM Public HTML Files
for /r public %%f in (*.html) do (
    echo. >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    echo FILE: %%f >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    type "%%f" >> ALL_CODE_COMPLETE.txt
)

REM CSS Files
for /r public\assets\css %%f in (*.css) do (
    echo. >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    echo FILE: %%f >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    type "%%f" >> ALL_CODE_COMPLETE.txt
)

REM JavaScript Files
for /r public\assets\js %%f in (*.js) do (
    echo. >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    echo FILE: %%f >> ALL_CODE_COMPLETE.txt
    echo ================================================================================ >> ALL_CODE_COMPLETE.txt
    type "%%f" >> ALL_CODE_COMPLETE.txt
)

REM Root Files
for %%f in (index.html public.html admin.html) do (
    if exist "%%f" (
        echo. >> ALL_CODE_COMPLETE.txt
        echo ================================================================================ >> ALL_CODE_COMPLETE.txt
        echo FILE: %%f >> ALL_CODE_COMPLETE.txt
        echo ================================================================================ >> ALL_CODE_COMPLETE.txt
        type "%%f" >> ALL_CODE_COMPLETE.txt
    )
)

echo.
echo Done! File created: ALL_CODE_COMPLETE.txt
echo.
pause
