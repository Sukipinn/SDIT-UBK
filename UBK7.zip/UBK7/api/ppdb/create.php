<?php
/** PPDB Create (PUBLIC) */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    // Validate all required fields
    $required = ['nama_siswa', 'tempat_lahir', 'tanggal_lahir', 'jenis_kelamin', 
                 'alamat', 'nama_ayah', 'nama_ibu', 'no_hp', 'email'];
    
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            jsonResponse(false, "Field $field harus diisi");
        }
    }
    
    $data = [
        'nama_siswa' => sanitizeInput($_POST['nama_siswa']),
        'tempat_lahir' => sanitizeInput($_POST['tempat_lahir']),
        'tanggal_lahir' => sanitizeInput($_POST['tanggal_lahir']),
        'jenis_kelamin' => sanitizeInput($_POST['jenis_kelamin']),
        'alamat' => sanitizeInput($_POST['alamat']),
        'nama_ayah' => sanitizeInput($_POST['nama_ayah']),
        'nama_ibu' => sanitizeInput($_POST['nama_ibu']),
        'no_hp' => sanitizeInput($_POST['no_hp']),
        'email' => sanitizeInput($_POST['email'])
    ];
    
    // Handle file uploads
    $uploadDir = '../../uploads/ppdb/';
    if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
    
    $dokumenFields = ['dokumen_akta', 'dokumen_kk', 'foto_siswa'];
    foreach ($dokumenFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
            if (!in_array($_FILES[$field]['type'], $allowedTypes)) {
                jsonResponse(false, "Format file $field tidak valid");
            }
            
            if ($_FILES[$field]['size'] > 5 * 1024 * 1024) {
                jsonResponse(false, "Ukuran file $field maksimal 5MB");
            }
            
            $filename = generateUniqueFilename($_FILES[$field]['name']);
            $targetPath = $uploadDir . $filename;
            
            if (move_uploaded_file($_FILES[$field]['tmp_name'], $targetPath)) {
                $data[$field] = 'uploads/ppdb/' . $filename;
            }
        } else {
            $data[$field] = null;
        }
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        INSERT INTO ppdb (nama_siswa, tempat_lahir, tanggal_lahir, jenis_kelamin, alamat, 
                         nama_ayah, nama_ibu, no_hp, email, dokumen_akta, dokumen_kk, foto_siswa, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ");
    $stmt->execute([
        $data['nama_siswa'], $data['tempat_lahir'], $data['tanggal_lahir'], $data['jenis_kelamin'],
        $data['alamat'], $data['nama_ayah'], $data['nama_ibu'], $data['no_hp'], $data['email'],
        $data['dokumen_akta'], $data['dokumen_kk'], $data['foto_siswa']
    ]);
    
    $newId = $pdo->lastInsertId();
    $nomorPendaftaran = 'PPDB-' . date('Y') . '-' . str_pad($newId, 4, '0', STR_PAD_LEFT);
    
    jsonResponse(true, 'Pendaftaran berhasil! Nomor pendaftaran Anda: ' . $nomorPendaftaran, [
        'id' => $newId,
        'nomor_pendaftaran' => $nomorPendaftaran
    ]);
} catch (PDOException $e) {
    error_log("PPDB create error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat menyimpan data pendaftaran');
}
?>
