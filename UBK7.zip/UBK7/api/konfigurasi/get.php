<?php
/** Konfigurasi Get */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $key = isset($_GET['key']) ? sanitizeInput($_GET['key']) : '';
    
    $pdo = getDBConnection();
    
    if (!empty($key)) {
        $stmt = $pdo->prepare("SELECT * FROM konfigurasi WHERE `key` = ?");
        $stmt->execute([$key]);
        $config = $stmt->fetch();
        jsonResponse(true, 'Data konfigurasi berhasil diambil', $config);
    } else {
        // Return all config as key-value object
        $stmt = $pdo->query("SELECT * FROM konfigurasi");
        $configs = $stmt->fetchAll();
        
        $result = [];
        foreach ($configs as $config) {
            $result[$config['key']] = $config['value'];
        }
        
        jsonResponse(true, 'Data konfigurasi berhasil diambil', $result);
    }
} catch (PDOException $e) {
    error_log("Konfigurasi get error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
