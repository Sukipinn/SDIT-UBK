<?php
/**
 * API: Get Single Guru by ID
 * Method: GET
 * Params: id (required)
 */

require_once '../config/database.php';

header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    
    // Get ID from query parameter
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID guru tidak valid');
    }
    
    // Get guru by ID
    $stmt = $conn->prepare("
        SELECT id, nama, jabatan, pendidikan, foto, created_at, updated_at
        FROM guru
        WHERE id = ?
    ");
    
    $stmt->execute([$id]);
    $guru = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$guru) {
        jsonResponse(false, 'Guru tidak ditemukan');
    }
    
    jsonResponse(true, 'Data guru berhasil diambil', $guru);
    
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
