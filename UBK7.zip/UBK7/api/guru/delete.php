<?php
/** Guru Delete */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
$admin = requireAdmin();

try {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
    if ($id <= 0) jsonResponse(false, 'ID tidak valid');
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $stmt->execute([$id]);
    $guru = $stmt->fetch();
    
    if (!$guru) jsonResponse(false, 'Guru tidak ditemukan');
    
    $stmt = $pdo->prepare("DELETE FROM guru WHERE id = ?");
    $stmt->execute([$id]);
    
    if ($guru['foto'] && file_exists('../../' . $guru['foto'])) {
        unlink('../../' . $guru['foto']);
    }
    
    jsonResponse(true, 'Guru berhasil dihapus');
} catch (PDOException $e) {
    error_log("Guru delete error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
