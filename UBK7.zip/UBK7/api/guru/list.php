<?php
/**
 * Guru List API Endpoint
 */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
    
    $query = "SELECT * FROM guru WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $query .= " AND (nama LIKE ? OR jabatan LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $query .= " ORDER BY CASE WHEN jabatan LIKE '%Kepala Sekolah%' THEN 0 ELSE 1 END, created_at ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $guru = $stmt->fetchAll();
    
    jsonResponse(true, 'Data guru berhasil diambil', $guru);
} catch (PDOException $e) {
    error_log("Guru list error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat mengambil data');
}
?>
