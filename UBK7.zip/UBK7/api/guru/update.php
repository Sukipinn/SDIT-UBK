<?php
/** Guru Update */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
$admin = requireAdmin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}
try {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $nama = isset($_POST['nama']) ? sanitizeInput($_POST['nama']) : '';
    $jabatan = isset($_POST['jabatan']) ? sanitizeInput($_POST['jabatan']) : '';
    $pendidikan = isset($_POST['pendidikan']) ? sanitizeInput($_POST['pendidikan']) : '';
    
    if ($id <= 0 || empty($nama) || empty($jabatan) || empty($pendidikan)) {
        jsonResponse(false, 'Data tidak lengkap');
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    
    if (!$existing) jsonResponse(false, 'Guru tidak ditemukan');
    
    $foto = $existing['foto'];
    
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../../uploads/guru/';
        if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
        
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        if (!in_array($_FILES['foto']['type'], $allowedTypes)) {
            jsonResponse(false, 'Format foto tidak valid');
        }
        
        $filename = generateUniqueFilename($_FILES['foto']['name']);
        $targetPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $targetPath)) {
            if ($existing['foto'] && file_exists('../../' . $existing['foto'])) {
                unlink('../../' . $existing['foto']);
            }
            $foto = 'uploads/guru/' . $filename;
        }
    }
    
    $stmt = $pdo->prepare("UPDATE guru SET nama = ?, jabatan = ?, foto = ?, pendidikan = ? WHERE id = ?");
    $stmt->execute([$nama, $jabatan, $foto, $pendidikan, $id]);
    
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse(true, 'Data guru berhasil diupdate', $stmt->fetch());
} catch (PDOException $e) {
    error_log("Guru update error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
