<?php
/**
 * Guru Create API Endpoint
 */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$admin = requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    $nama = isset($_POST['nama']) ? sanitizeInput($_POST['nama']) : '';
    $jabatan = isset($_POST['jabatan']) ? sanitizeInput($_POST['jabatan']) : '';
    $pendidikan = isset($_POST['pendidikan']) ? sanitizeInput($_POST['pendidikan']) : '';
    $foto = null;
    
    if (empty($nama) || empty($jabatan) || empty($pendidikan)) {
        jsonResponse(false, 'Semua field harus diisi');
    }
    
    // Handle file upload
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../../uploads/guru/';
        if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
        
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        if (!in_array($_FILES['foto']['type'], $allowedTypes)) {
            jsonResponse(false, 'Format foto tidak valid. Gunakan JPG atau PNG');
        }
        
        if ($_FILES['foto']['size'] > 5 * 1024 * 1024) {
            jsonResponse(false, 'Ukuran foto maksimal 5MB');
        }
        
        $filename = generateUniqueFilename($_FILES['foto']['name']);
        $targetPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $targetPath)) {
            $foto = 'uploads/guru/' . $filename;
        }
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO guru (nama, jabatan, foto, pendidikan) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nama, $jabatan, $foto, $pendidikan]);
    
    $newId = $pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $stmt->execute([$newId]);
    
    jsonResponse(true, 'Data guru berhasil ditambahkan', $stmt->fetch());
} catch (PDOException $e) {
    error_log("Guru create error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat menyimpan data');
}
?>
