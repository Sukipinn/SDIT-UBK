<?php
/** Kontak Create (PUBLIC) */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $nama = isset($input['nama']) ? sanitizeInput($input['nama']) : 
            (isset($_POST['nama']) ? sanitizeInput($_POST['nama']) : '');
    $email = isset($input['email']) ? sanitizeInput($input['email']) : 
             (isset($_POST['email']) ? sanitizeInput($_POST['email']) : '');
    $telepon = isset($input['telepon']) ? sanitizeInput($input['telepon']) : 
               (isset($_POST['telepon']) ? sanitizeInput($_POST['telepon']) : '');
    $pesan = isset($input['pesan']) ? sanitizeInput($input['pesan']) : 
             (isset($_POST['pesan']) ? sanitizeInput($_POST['pesan']) : '');
    
    if (empty($nama) || empty($email) || empty($pesan)) {
        jsonResponse(false, 'Nama, email, dan pesan harus diisi');
    }
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Format email tidak valid');
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO kontak (nama, email, telepon, pesan, is_read) VALUES (?, ?, ?, ?, FALSE)");
    $stmt->execute([$nama, $email, $telepon, $pesan]);
    
    jsonResponse(true, 'Pesan Anda berhasil dikirim. Terima kasih!');
} catch (PDOException $e) {
    error_log("Kontak create error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat mengirim pesan');
}
?>
