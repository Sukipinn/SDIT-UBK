<?php
/**
 * Check Session API Endpoint
 * SDIT Umar Bin Khattab Kudus
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');

$admin = validateAdminSession();

if ($admin) {
    jsonResponse(true, 'Session valid', ['admin' => $admin]);
} else {
    http_response_code(401);
    jsonResponse(false, 'Session tidak valid atau sudah kadaluarsa');
}
?>
