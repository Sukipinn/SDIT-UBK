<?php
/**
 * Logout API Endpoint
 * SDIT Umar Bin Khattab Kudus
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    session_start();
    
    if (isset($_SESSION['session_id'])) {
        // Hapus session dari database
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("DELETE FROM sessions WHERE id = ?");
        $stmt->execute([$_SESSION['session_id']]);
    }
    
    // Destroy session
    session_unset();
    session_destroy();
    
    jsonResponse(true, 'Logout berhasil');
    
} catch (PDOException $e) {
    error_log("Logout error: " . $e->getMessage());
    jsonResponse(true, 'Logout berhasil'); // Tetap return success meskipun ada error
}
?>
