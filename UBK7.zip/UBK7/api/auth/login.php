<?php
/**
 * Login API Endpoint
 * SDIT Umar Bin Khattab Kudus
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');


// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    // Get POST data
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Ambil dari JSON atau POST biasa
    $username = isset($input['username']) ? sanitizeInput($input['username']) : 
                (isset($_POST['username']) ? sanitizeInput($_POST['username']) : '');
    $password = isset($input['password']) ? $input['password'] : 
                (isset($_POST['password']) ? $_POST['password'] : '');
    
    // Validasi input
    if (empty($username) || empty($password)) {
        jsonResponse(false, 'Username dan password harus diisi');
    }
    
    // Get database connection
    $pdo = getDBConnection();
    
    // Cari user berdasarkan username
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();
    
    // Validasi user dan password
    if (!$admin || !password_verify($password, $admin['password'])) {
        http_response_code(401);
        jsonResponse(false, 'Username atau password salah');
    }
    
    // Start session
    session_start();
    
    // Generate session ID
    $sessionId = bin2hex(random_bytes(32));
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Simpan session ke database
    $stmt = $pdo->prepare("
        INSERT INTO sessions (id, admin_id, ip_address, user_agent, last_activity) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$sessionId, $admin['id'], $ipAddress, $userAgent]);
    
    // Set session variables
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['username'] = $admin['username'];
    $_SESSION['nama_lengkap'] = $admin['nama_lengkap'];
    $_SESSION['session_id'] = $sessionId;
    
    // Return success response
    jsonResponse(true, 'Login berhasil', [
        'admin' => [
            'id' => $admin['id'],
            'username' => $admin['username'],
            'nama_lengkap' => $admin['nama_lengkap'],
            'email' => $admin['email']
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Login error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan. Silakan coba lagi.');
}
?>
