<?php
/**
 * API: Update Ekstrakurikuler
 */

require_once '../config/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $id = isset($input['id']) ? (int)$input['id'] : 0;
    $nama = sanitizeInput($input['nama'] ?? '');
    $deskripsi = sanitizeInput($input['deskripsi'] ?? '');
    $icon = sanitizeInput($input['icon'] ?? '⚽');
    
    if ($id <= 0 || empty($nama)) {
        jsonResponse(false, 'ID dan nama harus diisi');
    }
    
    $stmt = $conn->prepare("UPDATE ekstrakurikuler SET nama = ?, deskripsi = ?, icon = ? WHERE id = ?");
    $stmt->execute([$nama, $deskripsi, $icon, $id]);
    
    jsonResponse(true, 'Ekstrakurikuler berhasil diupdate');
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
