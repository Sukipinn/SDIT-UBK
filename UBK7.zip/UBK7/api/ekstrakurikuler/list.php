<?php
/** Ekstrakurikuler List */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM ekstrakurikuler ORDER BY created_at ASC");
    $stmt->execute();
    jsonResponse(true, 'Data ekstrakurikuler berhasil diambil', $stmt->fetchAll());
} catch (PDOException $e) {
    error_log("Ekstrakurikuler list error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
