<?php
/**
 * API: Get Single Ekstrakurikuler by ID
 */

require_once '../config/database.php';
header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID tidak valid');
    }
    
    $stmt = $conn->prepare("SELECT * FROM ekstrakurikuler WHERE id = ?");
    $stmt->execute([$id]);
    $ekskul = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$ekskul) {
        jsonResponse(false, 'Ekstrakurikuler tidak ditemukan');
    }
    
    jsonResponse(true, 'Data berhasil diambil', $ekskul);
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
