<?php
/**
 * API: Create Ekstrakurikuler
 */

require_once '../config/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $nama = sanitizeInput($input['nama'] ?? '');
    $deskripsi = sanitizeInput($input['deskripsi'] ?? '');
    $icon = sanitizeInput($input['icon'] ?? '⚽');
    
    if (empty($nama)) {
        jsonResponse(false, 'Nama ekstrakurikuler harus diisi');
    }
    
    $stmt = $conn->prepare("INSERT INTO ekstrakurikuler (nama, deskripsi, icon) VALUES (?, ?, ?)");
    $stmt->execute([$nama, $deskripsi, $icon]);
    
    $newId = $conn->lastInsertId();
    $stmt = $conn->prepare("SELECT * FROM ekstrakurikuler WHERE id = ?");
    $stmt->execute([$newId]);
    
    jsonResponse(true, 'Ekstrakurikuler berhasil ditambahkan', $stmt->fetch());
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
