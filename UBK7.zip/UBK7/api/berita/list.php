<?php
/**
 * Berita List API Endpoint
 * SDIT Umar Bin Khattab Kudus
 * 
 * GET - Mendapatkan semua berita (public access)
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Get query parameters
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : null;
    $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
    
    // Build query
    $query = "SELECT * FROM berita WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $query .= " AND (judul LIKE ? OR isi LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $query .= " ORDER BY tanggal DESC, created_at DESC";
    
    if ($limit) {
        $query .= " LIMIT ?";
        $params[] = $limit;
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $berita = $stmt->fetchAll();
    
    jsonResponse(true, 'Data berita berhasil diambil', $berita);
    
} catch (PDOException $e) {
    error_log("Berita list error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat mengambil data');
}
?>
