<?php
/**
 * Berita Create API Endpoint
 * SDIT Umar Bin Khattab Kudus
 * 
 * POST - Membuat berita baru (admin only)
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');

// Cek autentikasi admin
$admin = requireAdmin();

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    // Get form data
    $judul = isset($_POST['judul']) ? sanitizeInput($_POST['judul']) : '';
    $isi = isset($_POST['isi']) ? trim($_POST['isi']) : ''; // Tidak di-sanitize karena bisa HTML
    $tanggal = isset($_POST['tanggal']) ? sanitizeInput($_POST['tanggal']) : date('Y-m-d');
    $gambar = null;
    
    // Validasi required fields
    if (empty($judul) || empty($isi)) {
        jsonResponse(false, 'Judul dan isi berita harus diisi');
    }
    
    // Handle file upload
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../../uploads/berita/';
        
        // Buat directory jika belum ada
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        $fileType = $_FILES['gambar']['type'];
        
        if (!in_array($fileType, $allowedTypes)) {
            jsonResponse(false, 'Format gambar tidak valid. Gunakan JPG atau PNG');
        }
        
        // Cek ukuran file (max 5MB)
        if ($_FILES['gambar']['size'] > 5 * 1024 * 1024) {
            jsonResponse(false, 'Ukuran gambar maksimal 5MB');
        }
        
        $filename = generateUniqueFilename($_FILES['gambar']['name']);
        $targetPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetPath)) {
            $gambar = 'uploads/berita/' . $filename;
        } else {
            jsonResponse(false, 'Gagal mengupload gambar');
        }
    }
    
    // Insert ke database
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        INSERT INTO berita (judul, isi, gambar, tanggal) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$judul, $isi, $gambar, $tanggal]);
    
    $newId = $pdo->lastInsertId();
    
    // Get inserted data
    $stmt = $pdo->prepare("SELECT * FROM berita WHERE id = ?");
    $stmt->execute([$newId]);
    $newBerita = $stmt->fetch();
    
    jsonResponse(true, 'Berita berhasil ditambahkan', $newBerita);
    
} catch (PDOException $e) {
    error_log("Berita create error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat menyimpan data');
}
?>
