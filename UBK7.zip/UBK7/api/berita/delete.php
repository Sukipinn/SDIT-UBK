<?php
/**
 * Berita Delete API Endpoint
 * SDIT Umar Bin Khattab Kudus
 * 
 * POST/DELETE - Hapus berita (admin only)
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Cek autentikasi admin
$admin = requireAdmin();

try {
    // Get ID dari POST atau query parameter
    $id = 0;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    } else if ($_SERVER['REQUEST_METHOD'] === 'DELETE' || $_SERVER['REQUEST_METHOD'] === 'GET') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    }
    
    if ($id <= 0) {
        jsonResponse(false, 'ID berita tidak valid');
    }
    
    $pdo = getDBConnection();
    
    // Get berita data untuk hapus gambar
    $stmt = $pdo->prepare("SELECT * FROM berita WHERE id = ?");
    $stmt->execute([$id]);
    $berita = $stmt->fetch();
    
    if (!$berita) {
        jsonResponse(false, 'Berita tidak ditemukan');
    }
    
    // Hapus dari database
    $stmt = $pdo->prepare("DELETE FROM berita WHERE id = ?");
    $stmt->execute([$id]);
    
    // Hapus gambar jika ada
    if ($berita['gambar'] && file_exists('../../' . $berita['gambar'])) {
        unlink('../../' . $berita['gambar']);
    }
    
    jsonResponse(true, 'Berita berhasil dihapus');
    
} catch (PDOException $e) {
    error_log("Berita delete error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat menghapus data');
}
?>
