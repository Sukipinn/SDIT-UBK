<?php
/**
 * Berita Update API Endpoint
 * SDIT Umar Bin Khattab Kudus
 * 
 * POST - Update berita (admin only)
 */

require_once '../config/database.php';

// Set headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Cek autentikasi admin
$admin = requireAdmin();

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}

try {
    // Get form data
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $judul = isset($_POST['judul']) ? sanitizeInput($_POST['judul']) : '';
    $isi = isset($_POST['isi']) ? trim($_POST['isi']) : '';
    $tanggal = isset($_POST['tanggal']) ? sanitizeInput($_POST['tanggal']) : date('Y-m-d');
    
    // Validasi
    if ($id <= 0) {
        jsonResponse(false, 'ID berita tidak valid');
    }
    
    if (empty($judul) || empty($isi)) {
        jsonResponse(false, ' Judul dan isi berita harus diisi');
    }
    
    $pdo = getDBConnection();
    
    // Cek apakah berita exists
    $stmt = $pdo->prepare("SELECT * FROM berita WHERE id = ?");
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    
    if (!$existing) {
        jsonResponse(false, 'Berita tidak ditemukan');
    }
    
    $gambar = $existing['gambar']; // Keep existing gambar
    
    // Handle file upload jika ada
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../../uploads/berita/';
        
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        $fileType = $_FILES['gambar']['type'];
        
        if (!in_array($fileType, $allowedTypes)) {
            jsonResponse(false, 'Format gambar tidak valid. Gunakan JPG atau PNG');
        }
        
        if ($_FILES['gambar']['size'] > 5 * 1024 * 1024) {
            jsonResponse(false, 'Ukuran gambar maksimal 5MB');
        }
        
        $filename = generateUniqueFilename($_FILES['gambar']['name']);
        $targetPath = $uploadDir . $filename;
        
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetPath)) {
            // Hapus gambar lama jika ada
            if ($existing['gambar'] && file_exists('../../' . $existing['gambar'])) {
                unlink('../../' . $existing['gambar']);
            }
            $gambar = 'uploads/berita/' . $filename;
        } else {
            jsonResponse(false, 'Gagal mengupload gambar');
        }
    }
    
    // Update database
    $stmt = $pdo->prepare("
        UPDATE berita 
        SET judul = ?, isi = ?, gambar = ?, tanggal = ? 
        WHERE id = ?
    ");
    $stmt->execute([$judul, $isi, $gambar, $tanggal, $id]);
    
    // Get updated data
    $stmt = $pdo->prepare("SELECT * FROM berita WHERE id = ?");
    $stmt->execute([$id]);
    $updated = $stmt->fetch();
    
    jsonResponse(true, 'Berita berhasil diupdate', $updated);
    
} catch (PDOException $e) {
    error_log("Berita update error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan saat mengupdate data');
}
?>
