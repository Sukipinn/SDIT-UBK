<?php
/** Prestasi Create */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
$admin = requireAdmin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(false, 'Method not allowed');
}
try {
    // Read JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $judul = isset($input['judul']) ? sanitizeInput($input['judul']) : '';
    $kategori = isset($input['kategori']) ? sanitizeInput($input['kategori']) : '';
    $tingkat = isset($input['tingkat']) ? sanitizeInput($input['tingkat']) : '';
    $tahun = isset($input['tahun']) ? (int)$input['tahun'] : date('Y');
    $deskripsi = isset($input['deskripsi']) ? trim($input['deskripsi']) : '';
    
    if (empty($judul) || empty($kategori) || empty($tingkat)) {
        jsonResponse(false, 'Judul, kategori, dan tingkat harus diisi');
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO prestasi (judul, kategori, tingkat, tahun, deskripsi) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$judul, $kategori, $tingkat, $tahun, $deskripsi]);
    
    $newId = $pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT * FROM prestasi WHERE id = ?");
    $stmt->execute([$newId]);
    jsonResponse(true, 'Prestasi berhasil ditambahkan', $stmt->fetch());
} catch (PDOException $e) {
    error_log("Prestasi create error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
