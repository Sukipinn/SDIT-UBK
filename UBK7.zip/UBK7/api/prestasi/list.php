<?php
/** Prestasi List */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    $kategori = isset($_GET['kategori']) ? sanitizeInput($_GET['kategori']) : '';
    $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
    
    $query = "SELECT * FROM prestasi WHERE 1=1";
    $params = [];
    
    if (!empty($kategori) && $kategori !== 'semua') {
        $query .= " AND kategori = ?";
        $params[] = $kategori;
    }
    
    if (!empty($search)) {
        $query .= " AND (judul LIKE ? OR deskripsi LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $query .= " ORDER BY tahun DESC, created_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    jsonResponse(true, 'Data prestasi berhasil diambil', $stmt->fetchAll());
} catch (PDOException $e) {
    error_log("Prestasi list error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
