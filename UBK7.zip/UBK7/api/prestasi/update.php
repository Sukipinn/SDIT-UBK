<?php
/**
 * API: Update Prestasi
 * Method: POST
 * Body: JSON {id, judul, kategori, tingkat, tahun, deskripsi}
 */

require_once '../config/database.php';

header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $id = isset($input['id']) ? (int)$input['id'] : 0;
    $judul = sanitizeInput($input['judul'] ?? '');
    $kategori = sanitizeInput($input['kategori'] ?? '');
    $tingkat = sanitizeInput($input['tingkat'] ?? '');
    $tahun = isset($input['tahun']) ? (int)$input['tahun'] : 0;
    $deskripsi = sanitizeInput($input['deskripsi'] ?? '');
    
    // Validation
    if ($id <= 0) {
        jsonResponse(false, 'ID tidak valid');
    }
    
    if (empty($judul) || empty($kategori) || empty($tingkat) || $tahun <= 0) {
        jsonResponse(false, 'Semua field wajib diisi');
    }
    
    // Check if exists
    $stmt = $conn->prepare("SELECT id FROM prestasi WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(false, 'Prestasi tidak ditemukan');
    }
    
    // Update
    $stmt = $conn->prepare("
        UPDATE prestasi 
        SET judul = ?, kategori = ?, tingkat = ?, tahun = ?, deskripsi = ?
        WHERE id = ?
    ");
    
    $stmt->execute([$judul, $kategori, $tingkat, $tahun, $deskripsi, $id]);
    
    jsonResponse(true, 'Prestasi berhasil diupdate');
    
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
