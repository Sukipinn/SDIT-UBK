<?php
/**
 * API: Delete Prestasi
 * Method: DELETE
 * Params: id (required)
 */

require_once '../config/database.php';

header('Content-Type: application/json');

// Allow DELETE method
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID tidak valid');
    }
    
    // Check if exists
    $stmt = $conn->prepare("SELECT id FROM prestasi WHERE id = ?");
    $stmt->execute([$id]);
    if (!$stmt->fetch()) {
        jsonResponse(false, 'Prestasi tidak ditemukan');
    }
    
    // Delete
    $stmt = $conn->prepare("DELETE FROM prestasi WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(true, 'Prestasi berhasil dihapus');
    
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
