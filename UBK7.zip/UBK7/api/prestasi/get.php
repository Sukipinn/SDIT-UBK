<?php
/**
 * API: Get Single Prestasi by ID
 * Method: GET
 * Params: id (required)
 */

require_once '../config/database.php';

header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID prestasi tidak valid');
    }
    
    $stmt = $conn->prepare("
        SELECT id, judul, kategori, tingkat, tahun, deskripsi, created_at
        FROM prestasi
        WHERE id = ?
    ");
    
    $stmt->execute([$id]);
    $prestasi = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$prestasi) {
        jsonResponse(false, 'Prestasi tidak ditemukan');
    }
    
    jsonResponse(true, 'Data prestasi berhasil diambil', $prestasi);
    
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
