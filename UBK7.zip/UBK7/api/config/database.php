<?php
/**
 * Database Connection
 * SDIT Umar Bin Khattab Kudus
 * 
 * File ini berisi konfigurasi koneksi database menggunakan PDO
 */

// Konfigurasi database
define('DB_HOST', 'localhost');
define('DB_NAME', 'sdit_ubk');
define('DB_USER', 'root');
define('DB_PASS', ''); // Kosong untuk XAMPP default

// Timezone
date_default_timezone_set('Asia/Jakarta');

/**
 * Fungsi untuk mendapatkan koneksi database
 * @return PDO Database connection object
 */
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
        
    } catch (PDOException $e) {
        // Log error (untuk production sebaiknya log ke file)
        error_log("Database connection error: " . $e->getMessage());
        
        // Return error response
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Koneksi database gagal. Silakan coba lagi.'
        ]);
        exit;
    }
}

/**
 * Fungsi helper untuk response JSON
 */
function jsonResponse($success, $message, $data = null) {
    header('Content-Type: application/json');
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

/**
 * Fungsi untuk validasi session admin
 * @return array Admin data jika valid, false jika tidak
 */
function validateAdminSession() {
    session_start();
    
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['session_id'])) {
        return false;
    }
    
    try {
        $pdo = getDBConnection();
        
        // Check session di database
        $stmt = $pdo->prepare("
            SELECT a.id, a.username, a.nama_lengkap, a.email 
            FROM admins a
            JOIN sessions s ON a.id = s.admin_id
            WHERE s.id = ? AND a.id = ?
        ");
        $stmt->execute([$_SESSION['session_id'], $_SESSION['admin_id']]);
        
        $admin = $stmt->fetch();
        
        if ($admin) {
            // Update last activity
            $updateStmt = $pdo->prepare("UPDATE sessions SET last_activity = NOW() WHERE id = ?");
            $updateStmt->execute([$_SESSION['session_id']]);
            
            return $admin;
        }
        
        return false;
        
    } catch (PDOException $e) {
        error_log("Session validation error: " . $e->getMessage());
        return false;
    }
}

/**
 * Fungsi untuk cek apakah request dari admin (untuk API endpoint)
 */
function requireAdmin() {
    $admin = validateAdminSession();
    
    if (!$admin) {
        http_response_code(401);
        jsonResponse(false, 'Unauthorized. Silakan login terlebih dahulu.');
    }
    
    return $admin;
}

/**
 * Fungsi untuk sanitasi input
 */
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

/**
 * Fungsi untuk generate unique filename
 */
function generateUniqueFilename($originalName) {
    $extension = pathinfo($originalName, PATHINFO_EXTENSION);
    $filename = pathinfo($originalName, PATHINFO_FILENAME);
    $sanitized = preg_replace('/[^a-zA-Z0-9]/', '_', $filename);
    return $sanitized . '_' . time() . '_' . uniqid() . '.' . $extension;
}
?>
