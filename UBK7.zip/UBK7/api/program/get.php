<?php
/**
 * API: Get Single Program by ID
 * Method: GET
 * Params: id (required)
 */

require_once '../config/database.php';
header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID program tidak valid');
    }
    
    $stmt = $conn->prepare("SELECT * FROM program WHERE id = ?");
    $stmt->execute([$id]);
    $program = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$program) {
        jsonResponse(false, 'Program tidak ditemukan');
    }
    
    jsonResponse(true, 'Data program berhasil diambil', $program);
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
