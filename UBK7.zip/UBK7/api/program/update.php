<?php
/**
 * API: Update Program
 * Method: POST
 * Body: JSON {id, nama, deskripsi, icon}
 */

require_once '../config/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $id = isset($input['id']) ? (int)$input['id'] : 0;
    $nama = sanitizeInput($input['nama'] ?? '');
    $deskripsi = sanitizeInput($input['deskripsi'] ?? '');
    $icon = sanitizeInput($input['icon'] ?? '📚');
    
    if ($id <= 0 || empty($nama)) {
        jsonResponse(false, 'ID dan nama program harus diisi');
    }
    
    $stmt = $conn->prepare("UPDATE program SET nama = ?, deskripsi = ?, icon = ? WHERE id = ?");
    $stmt->execute([$nama, $deskripsi, $icon, $id]);
    
    jsonResponse(true, 'Program berhasil diupdate');
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
