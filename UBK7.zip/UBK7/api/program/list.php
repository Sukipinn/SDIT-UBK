<?php
/** Program List */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM program ORDER BY urutan ASC, created_at ASC");
    $stmt->execute();
    jsonResponse(true, 'Data program berhasil diambil', $stmt->fetchAll());
} catch (PDOException $e) {
    error_log("Program list error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
