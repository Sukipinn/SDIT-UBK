<?php
/**
 * API: Delete Program
 * Method: DELETE
 * Params: id (required)
 */

require_once '../config/database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    jsonResponse(false, 'Method not allowed');
}

try {
    requireAdmin();
    $conn = getDBConnection();
    
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if ($id <= 0) {
        jsonResponse(false, 'ID tidak valid');
    }
    
    $stmt = $conn->prepare("DELETE FROM program WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(true, 'Program berhasil dihapus');
} catch (PDOException $e) {
    jsonResponse(false, 'Database error: ' . $e->getMessage());
}
