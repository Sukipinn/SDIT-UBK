<?php
/** Halaman Statis Get */
require_once '../config/database.php';
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

try {
    $slug = isset($_GET['slug']) ? sanitizeInput($_GET['slug']) : '';
    
    if (empty($slug)) {
        jsonResponse(false, 'Slug harus diisi');
    }
    
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM halaman_statis WHERE slug = ?");
    $stmt->execute([$slug]);
    $halaman = $stmt->fetch();
    
    if (!$halaman) {
        jsonResponse(false, 'Halaman tidak ditemukan');
    }
    
    jsonResponse(true, 'Data halaman berhasil diambil', $halaman);
} catch (PDOException $e) {
    error_log("Halaman statis get error: " . $e->getMessage());
    http_response_code(500);
    jsonResponse(false, 'Terjadi kesalahan');
}
?>
