# SDIT Umar Bin Khattab Kudus - Website Documentation

## 📋 Deskripsi Project

Website sekolah SDIT Umar Bin Khattab Kudus di bawah naungan Yayasan Al-Fath. Website ini memiliki dua tampilan utama:
1. **Website Publik** - untuk pengunjung umum (tanpa login)
2. **Admin Panel** - untuk pengelolaan data (login diperlukan)

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: PHP 7.4+ (Native)
- **Database**: MySQL 5.7+
- **Server**: Apache/Nginx dengan mod_rewrite
- **Design**: Islamic Theme - Modern & Clean

---

## 📁 Struktur Folder

```
UBK7/
├── database/
│   └── sdit_ubk.sql                # Database schema dan sample data
├── api/
│   ├── config/
│   │   └── database.php            # Database connection
│   ├── auth/                       # Authentication endpoints
│   │   ├── login.php
│   │   ├── logout.php
│   │   └── check_session.php
│   ├── berita/                     # News CRUD endpoints
│   │   ├── list.php
│   │   ├── create.php
│   │   ├── update.php
│   │   └── delete.php
│   ├── guru/                       # Teachers CRUD endpoints
│   ├── prestasi/                   # Achievements CRUD endpoints
│   ├── ekstrakurikuler/            # Extracurricular CRUD endpoints
│   ├── program/                    # Programs CRUD endpoints
│   ├── halaman_statis/             # Static pages endpoints
│   ├── ppdb/                       # Admission endpoints
│   ├── kontak/                     # Contact endpoints
│   └── konfigurasi/                # Configuration endpoints
├── public/
│   ├── index.html                  # Homepage
│   ├── profil.html                 # School profile
│   ├── guru.html                   # Teachers page
│   ├── program.html                # Programs page
│   ├── ekskul.html                 # Extracurricular page
│   ├── prestasi.html               # Achievements page
│   ├── ppdb.html                   # Admission form (!COMPLETED)
│   ├── kontak.html                 # Contact page
│   ├── assets/
│   │   ├── css/
│   │   │   └── style.css           # Main stylesheet (!COMPLETED)
│   │   ├── js/
│   │   │   ├── api.js              # API helpers (!COMPLETED)
│   │   │   └── main.js             # Main JavaScript (!COMPLETED)
│   │   └── images/
│   └── admin/
│       ├── login.html              # Admin login (!COMPLETED)
│       ├── dashboard.html          # Admin dashboard (!COMPLETED)
│       ├── berita/
│       │   ├── index.html          # Berita list (!COMPLETED)
│       │   ├── create.html
│       │   └── edit.html
│       ├── guru/
│       │   ├── index.html
│       │   ├── create.html
│       │   └── edit.html
│       ├── prestasi/
│       ├── ekstrakurikuler/
│       ├── program/
│       ├── halaman_statis/
│       ├── ppdb/
│       ├── kontak/
│       ├── config/
│       └── assets/
│           ├── css/
│           │   └── admin.css       # Admin styles (!COMPLETED)
│           └── js/
│               ├── admin.js
│               └── auth.js         # Auth helpers (!COMPLETED)
└── uploads/                        # Uploaded files
    ├── berita/
    ├── guru/
    ├── program/
    ├── ppdb/
    └── config/
```

> **Note**: Files marked with `(!COMPLETED)` telah selesai dibuat dan siap digunakan.

---

## ⚙️ Instalasi

### 1. Requirements

- **PHP** 7.4 atau lebih tinggi
- **MySQL** 5.7 atau lebih tinggi
- **Apache/Nginx** dengan mod_rewrite enabled
- **XAMPP/WAMP/MAMP** (untuk local development)

### 2. Setup Database

1. Buka **phpMyAdmin** atau MySQL client
2. Import file database:
   ```sql
   mysql -u root -p < database/sdit_ubk.sql
   ```
   Atau import manual file `database/sdit_ubk.sql` melalui phpMyAdmin

3. Database `sdit_ubk` akan otomatis terbuat dengan 11 tables dan sample data

### 3. Konfigurasi Database Connection

Edit file `api/config/database.php` jika diperlukan:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sdit_ubk');
define('DB_USER', 'root');
define('DB_PASS', ''); // Sesuaikan dengan password MySQL Anda
```

### 4. Setup Folder Uploads

Pastikan folder `uploads/` dan subfolder-nya memiliki permission yang tepat:

```bash
chmod -R 777 uploads/
```

Atau buat folder secara manual:
- `uploads/berita/`
- `uploads/guru/`
- `uploads/program/`
- `uploads/ppdb/`
- `uploads/config/`

### 5. Jalankan Server

Jika menggunakan **XAMPP**:
1. Copy folder `UBK7` ke `htdocs/`
2. Akses website via: `http://localhost/UBK7/public/`

Jika menggunakan **PHP Built-in Server**:
```bash
php -S localhost:8000 -t public/
```

---

## 👤 Default Login Admin

- **Username**: `admin`
- **Password**: `admin123`

> **PENTING**: Ganti password default setelah login pertama kali!

---

## 🌐 Halaman Website Publik

### 1. Homepage (`index.html`)
- Hero banner dengan CTA
- 3 Card keunggulan SDIT
- Sambutan kepala sekolah (dynamic dari database)
- Berita terbaru (3 berita terbaru)
- Prestasi terbaru (3 prestasi terbaru)

### 2. Profil (`profil.html`)
- Sejarah sekolah
- Visi & Misi
- Struktur organisasi

### 3. Guru (`guru.html`)
- Profil kepala sekolah (featured)
- Grid semua guru dengan foto

### 4. Program (`program.html`)
- Program Tahfidz Qur'an
- Program Sains & Teknologi
- Program Bina Pribadi Islami
- (All dynamically loaded from database)

### 5. Ekstrakurikuler (`ekskul.html`)
- Grid 16 ekstrakurikuler
- Hover animation

### 6. Prestasi (`prestasi.html`)
- Filter kategori: Semua, Akademik, Olahraga, Seni, Agama
- Grid prestasi siswa

### 7. PPDB (`ppdb.html`) ✅ COMPLETED
- Status PPDB (Dibuka/Ditutup) berdasarkan konfigurasi
- Form pendaftaran lengkap jika PPDB dibuka
- Upload dokumen (akta, KK, foto)
- Submit ke API dan tampilkan nomor pendaftaran

### 8. Kontak (`kontak.html`)
- Info kontak sekolah (dynamic dari konfigurasi)
- Google Maps embed
- Form pesan ke admin

---

## 🔐 Admin Panel

### Login (`admin/login.html`) ✅ COMPLETED
- Username & password authentication
- Session-based login
- Auto redirect ke dashboard jika berhasil

### Dashboard (`admin/dashboard.html`) ✅ COMPLETED
- Statistik:
  * Total berita
  * Total guru
  * Total pendaftar PPDB
  * Total pesan belum dibaca
- Quick actions button
- Sidebar navigation

### Berita Management (`admin/berita/`) ✅ List COMPLETED
- **List** ✅: Table berita dengan search dan delete
- **Create**: Form tambah berita + upload gambar
- **Edit**: Form edit berita + ganti gambar

### Guru Management (`admin/guru/`)
- **List**: Table guru dengan search dan delete
- **Create**: Form tambah guru + upload foto
- **Edit**: Form edit guru + ganti foto

### Prestasi Management (`admin/prestasi/`)
- **List**: Table prestasi dengan filter kategori
- **Create**: Form tambah prestasi
- **Edit**: Form edit prestasi

### Ekstrakurikuler Management (`admin/ekstrakurikuler/`)
- **List**: Table ekstrakurikuler
- **Create**: Form tambah ekskul
- **Edit**: Form edit ekskul

### Program Management (`admin/program/`)
- **List**: Table program
- **Create**: Form tambah program + icon upload
- **Edit**: Form edit program

### Halaman Statis (`admin/halaman_statis/edit.html`)
- Edit Sejarah Sekolah
- Edit Visi & Misi
- Edit Sambutan Kepala Sekolah
- **WYSIWYG Editor** (TinyMCE dari CDN)

### PPDB Management (`admin/ppdb/`)
- **List**: Daftar pendaftar dengan filter status
- **Detail**: View detail pendaftar + dokumen
- **Update Status**: Tandai Lolos / Tidak Lolos

### Kontak Management (`admin/kontak/`)
- **List**: Daftar pesan masuk
- **Mark as Read**: Tandai sudah dibaca
- **Delete**: Hapus pesan

### Konfigurasi (`admin/config/index.html`)
- Status PPDB (Open/Close)
- Info kontak sekolah
- Social media links
- Upload logo

---

## 🔌 API Endpoints

### Authentication
```
POST   /api/auth/login.php          - Login admin
POST   /api/auth/logout.php         - Logout admin
GET    /api/auth/check_session.php  - Validate session
```

### Berita (News)
```
GET    /api/berita/list.php         - Get all berita
POST   /api/berita/create.php       - Create berita (admin)
POST   /api/berita/update.php       - Update berita (admin)
POST   /api/berita/delete.php       - Delete berita (admin)
```

### Guru (Teachers)
```
GET    /api/guru/list.php           - Get all guru
POST   /api/guru/create.php         - Create guru (admin)
POST   /api/guru/update.php         - Update guru (admin)
POST   /api/guru/delete.php         - Delete guru (admin)
```

### Prestasi (Achievements)
```
GET    /api/prestasi/list.php       - Get all prestasi (optional: ?kategori=akademik)
POST   /api/prestasi/create.php     - Create prestasi (admin)
POST   /api/prestasi/update.php     - Update prestasi (admin)
POST   /api/prestasi/delete.php     - Delete prestasi (admin)
```

### Ekstrakurikuler
```
GET    /api/ekstrakurikuler/list.php  - Get all ekstrakurikuler
```

### Program
```
GET    /api/program/list.php        - Get all program
```

### Halaman Statis
```
GET    /api/halaman_statis/get.php  - Get page by slug (?slug=sejarah)
POST   /api/halaman_statis/update.php - Update page (admin)
```

### PPDB (Admission)
```
POST   /api/ppdb/create.php         - Submit PPDB form (public)
GET    /api/ppdb/list.php           - Get all applications (admin)
GET    /api/ppdb/detail.php         - Get application detail (admin)
POST   /api/ppdb/update_status.php  - Update application status (admin)
```

### Kontak (Contact)
```
POST   /api/kontak/create.php       - Submit contact form (public)
GET    /api/kontak/list.php         - Get all messages (admin)
POST   /api/kontak/mark_read.php    - Mark message as read (admin)
POST   /api/kontak/delete.php       - Delete message (admin)
```

### Konfigurasi (Settings)
```
GET    /api/konfigurasi/get.php     - Get all config (or by key: ?key=ppdb_status)
POST   /api/konfigurasi/update.php  - Update config (admin)
```

---

## 🎨 Design System

### Color Palette (Islamic Theme)
- **Primary Green**: `#2D7A3E`
- **Primary Dark**: `#1A5028`
- **Gold Accent**: `#D4AF37`
- **White**: `#FFFFFF`
- **Off White**: `#F8F9FA`

### Typography
- **Headings**: Poppins (Google Fonts)
- **Body**: Inter (Google Fonts)

### Components
- Navbar dengan sticky scroll effect
- Cards dengan hover animation
- Forms dengan validation
- Buttons dengan berbagai varian
- Footer dengan social media links
- Back to top button

---

## 📱 Responsive Design

Website fully responsive untuk:
- **Desktop**: 1024px+
- **Tablet**: 768px - 1024px
- **Mobile**: < 768px

Semua halaman public dan admin telah menggunakan responsive grid system.

---

## 🔒 Security Features

1. **Password Hashing**: Bcrypt via PHP `password_hash()`
2. **Prepared Statements**: PDO untuk prevent SQL injection
3. **Session Management**: Custom session table di database
4. **File Upload Validation**: 
   - Mime type checking
   - Size limits (5MB)
   - Unique filename generation
5. **Input Sanitization**: `htmlspecialchars()` dan `strip_tags()`
6. **Authentication Required**: Semua admin endpoints protected

---

## 📝 Next Steps / TODO

Untuk melengkapi website 100%, berikut file yang masih perlu dibuat:

### Public Pages (Remaining 5 pages)
- [ ] `profil.html`
- [ ] `guru.html`
- [ ] `program.html`
- [ ] `ekskul.html`
- [ ] `prestasi.html`
- [ ] `kontak.html`

### Admin Pages (Remaining ~18 pages)
- [ ] Berita: `create.html`, `edit.html`
- [ ] Guru: `index.html`, `create.html`, `edit.html`
- [ ] Prestasi: `index.html`, `create.html`, `edit.html`
- [ ] Ekstrakurikuler: `index.html`, `create.html`, `edit.html`
- [ ] Program: `index.html`, `create.html`, `edit.html`
- [ ] Halaman Statis: `edit.html`
- [ ] PPDB: `index.html`, `detail.html`
- [ ] Kontak: `index.html`
- [ ] Konfigurasi: `index.html`

### API Endpoints (Remaining ~12 endpoints)
- [ ] Prestasi: `update.php`, `delete.php`
- [ ] Ekstrakurikuler: `create.php`, `update.php`, `delete.php`
- [ ] Program: `create.php`, `update.php`, `delete.php`
- [ ] Halaman Statis: `update.php`
- [ ] PPDB: `list.php`, `detail.php`, `update_status.php`
- [ ] Kontak: `list.php`, `mark_read.php`, `delete.php`
- [ ] Konfigurasi: `update.php`

> **Note**: Semua file yang dibuat mengikuti pola yang sama dengan contoh yang sudah ada (berita). Copy dan sesuaikan field sesuai entity.

---

## 🚀 Deployment to Production

1. **Ganti Database Credentials** di `api/config/database.php`
2. **Ganti Default Admin Password**
3. **Set Proper File Permissions**:
   ```bash
   chmod 755 public/
   chmod 777 uploads/
   ```
4. **Enable HTTPS** (Let's Encrypt recommended)
5. **Setup .htaccess** untuk security:
   ```apache
   # Prevent directory browsing
   Options -Indexes
   
   # Protect uploads folder
   <FilesMatch "\.(php|php3|php4|php5|phtml)$">
       Order Deny,Allow
       Deny from all
   </FilesMatch>
   ```

---

## 📞 Support

Untuk pertanyaan atau bantuan, hubungi:
- **Email**: info@sdit-ubk.sch.id
- **Telepon**: (0291) 438888

---

## 📄 License

© 2026 SDIT Umar Bin Khattab Kudus - Yayasan Al-Fath. All rights reserved.

---

**Dibuat untuk PKL (Praktik Kerja Lapangan)**
Student: Akif  
Semester 6 - Universitas Muria Kudus
