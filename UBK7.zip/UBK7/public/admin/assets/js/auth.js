/**
 * Admin Authentication JavaScript
 * SDIT Umar Bin Khattab Kudus
 */

const API_BASE = window.location.origin + '/UBK7/api';

/**
 * Check if admin is logged in
 */
async function checkAuth() {
    try {
        console.log('🔍 Checking authentication...');
        const response = await fetch(`${API_BASE}/auth/check_session.php`);
        const data = await response.json();

        console.log('Auth check response:', data);

        if (!data.success) {
            console.warn('❌ Auth check failed:', data.message);
            // Redirect to login jika tidak authenticated
            if (!window.location.pathname.includes('login.html')) {
                console.log('Redirecting to login...');
                window.location.href = 'login.html';
            }
            return false;
        }

        console.log('✅ Auth check passed:', data.data.admin);
        return data.data.admin;
    } catch (error) {
        console.error('❌ Auth check error:', error);
        if (!window.location.pathname.includes('login.html')) {
            console.log('Redirecting to login due to error...');
            window.location.href = 'login.html';
        }
        return false;
    }
}

/**
 * Logout function
 */
async function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        try {
            await fetch(`${API_BASE}/auth/logout.php`);
            window.location.href = 'login.html';
        } catch (error) {
            console.error('Logout error:', error);
            // Force redirect anyway
            window.location.href = 'login.html';
        }
    }
}

/**
 * Auto-run auth check on admin pages (except login)
 */
if (!window.location.pathname.includes('login.html')) {
    document.addEventListener('DOMContentLoaded', async () => {
        const admin = await checkAuth();

        // Set admin name in UI if element exists
        const adminNameEl = document.getElementById('admin-name');
        if (adminNameEl && admin) {
            adminNameEl.textContent = admin.nama_lengkap;
        }

        const adminAvatarEl = document.getElementById('admin-avatar');
        if (adminAvatarEl && admin) {
            adminAvatarEl.textContent = admin.nama_lengkap.charAt(0).toUpperCase();
        }
    });
}

/**
 * Show notification
 */
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;

    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '16px 24px',
        borderRadius: '8px',
        backgroundColor: type === 'success' ? '#28A745' : '#DC3545',
        color: 'white',
        fontWeight: '500',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        zIndex: '9999',
        animation: 'slideInRight 0.3s ease',
        maxWidth: '400px'
    });

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOutRight {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(400px); opacity: 0; }
    }
`;
document.head.appendChild(style);
