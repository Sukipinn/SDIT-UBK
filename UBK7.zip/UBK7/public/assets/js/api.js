/**
 * API Helper Functions
 * SDIT Umar Bin Khattab Kudus
 */

const API_BASE_URL = '../api';

/**
 * Central fetch wrapper
 */
async function fetchAPI(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Get all berita
 */
async function getBerita(limit = null) {
    const url = limit ? `/berita/list.php?limit=${limit}` : '/berita/list.php';
    const response = await fetchAPI(url);
    return response.data || [];
}

/**
 * Get all guru
 */
async function getGuru() {
    const response = await fetchAPI('/guru/list.php');
    return response.data || [];
}

/**
 * Get prestasi dengan optional kategori filter
 */
async function getPrestasi(kategori = 'semua') {
    const url = kategori !== 'semua' ?
        `/prestasi/list.php?kategori=${kategori}` :
        '/prestasi/list.php';
    const response = await fetchAPI(url);
    return response.data || [];
}

/**
 * Get all ekstrakurikuler
 */
async function getEkskul() {
    const response = await fetchAPI('/ekstrakurikuler/list.php');
    return response.data || [];
}

/**
 * Get all program
 */
async function getProgram() {
    const response = await fetchAPI('/program/list.php');
    return response.data || [];
}

/**
 * Get halaman statis by slug
 */
async function getHalamanStatis(slug) {
    const response = await fetchAPI(`/halaman_statis/get.php?slug=${slug}`);
    return response.data || null;
}

/**
 * Get konfigurasi
 */
async function getKonfigurasi(key = '') {
    const url = key ? `/konfigurasi/get.php?key=${key}` : '/konfigurasi/get.php';
    const response = await fetchAPI(url);
    return response.data || null;
}

/**
 * Submit PPDB form
 */
async function submitPPDB(formData) {
    try {
        const response = await fetch(`${API_BASE_URL}/ppdb/create.php`, {
            method: 'POST',
            body: formData // FormData already includes correct headers
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Pendaftaran gagal');
        }

        return data;
    } catch (error) {
        console.error('PPDB Submit Error:', error);
        throw error;
    }
}

/**
 * Submit kontak message
 */
async function submitKontak(data) {
    const response = await fetchAPI('/kontak/create.php', {
        method: 'POST',
        body: JSON.stringify(data)
    });
    return response;
}

/**
 * Format tanggal Indonesia
 */
function formatTanggal(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', options);
}

/**
 * Show notification (toast)
 */
function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;

    // Add styles
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '16px 24px',
        borderRadius: '8px',
        backgroundColor: type === 'success' ? '#28A745' : '#DC3545',
        color: 'white',
        fontWeight: '500',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        zIndex: '9999',
        animation: 'slideInRight 0.3s ease',
        maxWidth: '400px'
    });

    document.body.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
