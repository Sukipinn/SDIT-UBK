-- =====================================================
-- Database: SDIT Umar Bin Khattab Kudus
-- Yayasan Al-Fath
-- =====================================================

-- Drop database jika sudah ada (hati-hati di production!)
DROP DATABASE IF EXISTS sdit_ubk;

-- Buat database baru
CREATE DATABASE sdit_ubk CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Gunakan database
USE sdit_ubk;

-- =====================================================
-- Table 1: admins
-- Admin users untuk login ke admin panel
-- =====================================================
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL COMMENT 'bcrypt hash',
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin (password: admin123)
INSERT INTO admins (username, password, nama_lengkap, email) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@sdit-ubk.sch.id');

-- =====================================================
-- Table 2: berita
-- News dan announcements
-- =====================================================
CREATE TABLE berita (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    isi TEXT NOT NULL,
    gambar VARCHAR(255) DEFAULT NULL,
    tanggal DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tanggal (tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data berita
INSERT INTO berita (judul, isi, tanggal) VALUES
('Penerimaan Peserta Didik Baru 2026/2027', 'SDIT Umar Bin Khattab Kudus membuka pendaftaran peserta didik baru untuk tahun ajaran 2026/2027. Dapatkan diskon pendaftaran untuk 50 pendaftar pertama!', '2026-01-10'),
('Juara 1 Lomba Tahfidz Tingkat Kabupaten', 'Alhamdulillah, siswa-siswi SDIT UBK meraih juara 1 pada lomba Tahfidz Qur\'an tingkat Kabupaten Kudus yang diselenggarakan pada 5 Januari 2026.', '2026-01-08'),
('Kegiatan Outbound Siswa Kelas 5', 'Siswa kelas 5 mengikuti kegiatan outbound di Colo Adventure Kudus sebagai bagian dari program pengembangan karakter dan teamwork.', '2026-01-05');

-- =====================================================
-- Table 3: guru
-- Data guru dan staff
-- =====================================================
CREATE TABLE guru (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jabatan VARCHAR(100) NOT NULL,
    foto VARCHAR(255) DEFAULT NULL,
    pendidikan VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_jabatan (jabatan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data guru
INSERT INTO guru (nama, jabatan, pendidikan) VALUES
('Ustadz Ahmad Fauzi, S.Pd.I', 'Kepala Sekolah', 'S1 Pendidikan Agama Islam'),
('Ustadzah Siti Nurhaliza, S.Pd', 'Wali Kelas 1A', 'S1 Pendidikan Guru Sekolah Dasar'),
('Ustadz Muhammad Ridwan, S.Pd', 'Wali Kelas 1B', 'S1 Pendidikan Guru Sekolah Dasar'),
('Ustadzah Fatimah Azzahra, S.Pd', 'Wali Kelas 2A', 'S1 Pendidikan Guru Sekolah Dasar'),
('Ustadz Yusuf Abdullah, S.Pd', 'Wali Kelas 2B', 'S1 Pendidikan Guru Sekolah Dasar'),
('Ustadzah Khadijah Amin, S.Pd', 'Wali Kelas 3A', 'S1 Pendidikan Guru Sekolah Dasar'),
('Ustadz Umar Hasan, S.Pd', 'Guru Tahfidz', 'S1 Pendidikan Agama Islam'),
('Ustadzah Aisyah Rahman, S.Pd', 'Guru Bahasa Inggris', 'S1 Pendidikan Bahasa Inggris'),
('Ustadz Ibrahim Malik, S.Kom', 'Guru Komputer', 'S1 Teknik Informatika'),
('Ustadzah Maryam Nur, S.Pd', 'Guru Seni & Budaya', 'S1 Pendidikan Seni');

-- =====================================================
-- Table 4: prestasi
-- Student achievements
-- =====================================================
CREATE TABLE prestasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    kategori ENUM('akademik', 'olahraga', 'seni', 'agama') NOT NULL,
    tingkat ENUM('sekolah', 'kecamatan', 'kabupaten', 'provinsi', 'nasional') NOT NULL,
    tahun YEAR NOT NULL,
    deskripsi TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_kategori (kategori),
    INDEX idx_tahun (tahun)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data prestasi
INSERT INTO prestasi (judul, kategori, tingkat, tahun, deskripsi) VALUES
('Juara 1 Tahfidz Juz 30', 'agama', 'kabupaten', 2026, 'Muhammad Azka Ramadhan meraih juara 1 lomba Tahfidz Juz 30 tingkat Kabupaten Kudus'),
('Juara 2 Olimpiade Matematika', 'akademik', 'provinsi', 2025, 'Salma Zahira meraih juara 2 Olimpiade Matematika SD tingkat Provinsi Jawa Tengah'),
('Juara 1 Futsal Antar SD', 'olahraga', 'kecamatan', 2025, 'Tim futsal putra SDIT UBK juara 1 pada kompetisi antar SD se-Kecamatan Kota'),
('Juara 3 Kaligrafi Arab', 'seni', 'kabupaten', 2025, 'Nabila Putri meraih juara 3 lomba kaligrafi Arab tingkat Kabupaten Kudus'),
('Juara 1 Cerdas Cermat Agama', 'agama', 'kabupaten', 2025, 'Tim cerdas cermat agama SDIT UBK juara 1 tingkat Kabupaten'),
('Juara 2 English Speech', 'akademik', 'kabupaten', 2025, 'Ahmad Zidan meraih juara 2 lomba pidato Bahasa Inggris'),
('Juara 1 Basket Mini', 'olahraga', 'sekolah', 2025, 'Kelas 5A juara 1 turnamen basket mini antar kelas'),
('Juara 1 Hadroh', 'seni', 'kecamatan', 2025, 'Grup hadroh SDIT UBK juara 1 festival seni Islami se-Kecamatan');

-- =====================================================
-- Table 5: ekstrakurikuler
-- Extracurricular activities
-- =====================================================
CREATE TABLE ekstrakurikuler (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    icon VARCHAR(50) DEFAULT '📚',
    warna VARCHAR(7) DEFAULT '#2D7A3E' COMMENT 'Hex color code',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data ekstrakurikuler (16 items)
INSERT INTO ekstrakurikuler (nama, deskripsi, icon, warna) VALUES
('Tahfidz Qur\'an', 'Program menghafal Al-Qur\'an dengan metode Yanbu\'a', '📖', '#2D7A3E'),
('Futsal', 'Latihan futsal untuk membentuk jiwa sportif dan teamwork', '⚽', '#1E88E5'),
('Basket', 'Ekstrakurikuler basket mini untuk siswa kelas 3-6', '🏀', '#FF6F00'),
('English Club', 'Meningkatkan kemampuan berbahasa Inggris dengan fun learning', '🗣️', '#8E24AA'),
('Sains Club', 'Eksperimen sains sederhana untuk menumbuhkan rasa ingin tahu', '🔬', '#00897B'),
('Komputer', 'Belajar dasar-dasar komputer dan coding untuk anak', '💻', '#5E35B1'),
('Kaligrafi Arab', 'Seni menulis indah kaligrafi Arab dengan khat Naskhi', '✍️', '#D4AF37'),
('Hadroh', 'Seni musik Islami dengan rebana dan vocals', '🥁', '#6D4C41'),
('Pramuka', 'Gerakan pramuka untuk membentuk karakter kepemimpinan', '🏕️', '#558B2F'),
('Karate', 'Bela diri karate untuk melatih disiplin dan percaya diri', '🥋', '#D32F2F'),
('Renang', 'Ekstrakurikuler renang di kolam renang Kudus', '🏊', '#0288D1'),
('Melukis', 'Seni melukis dan menggambar untuk kreativitas anak', '🎨', '#E91E63'),
('Tari Tradisional', 'Tarian tradisional Indonesia untuk melestarikan budaya', '💃', '#C2185B'),
('Robotik', 'Belajar merakit robot sederhana dan programming dasar', '🤖', '#455A64'),
('Jurnalistik', 'Belajar menulis berita dan membuat majalah dinding', '📰', '#F57C00'),
('Panahan', 'Seni memanah sesuai sunnah Rasulullah SAW', '🏹', '#4E342E');

-- =====================================================
-- Table 6: program
-- School programs
-- =====================================================
CREATE TABLE program (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT NOT NULL,
    icon VARCHAR(255) DEFAULT NULL,
    urutan INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_urutan (urutan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data program
INSERT INTO program (nama, deskripsi, urutan) VALUES
('Program Tahfidz Qur\'an', 'Program unggulan SDIT UBK dalam menghafal Al-Qur\'an dengan metode Yanbu\'a. Setiap siswa ditargetkan hafal minimal 1 juz selama di SDIT dengan bimbingan guru tahfidz berpengalaman.', 1),
('Program Sains & Teknologi', 'Pembelajaran berbasis STEM (Science, Technology, Engineering, Mathematics) dengan praktikum langsung, kunjungan ke science center, dan pelatihan robotik untuk menumbuhkan jiwa inovatif.', 2),
('Program Bina Pribadi Islami', 'Pembentukan karakter Islami melalui pembiasaan ibadah harian, akhlak mulia, dan nilai-nilai Islam dalam kehidupan sehari-hari. Dilengkapi dengan mentoring dan program tarbiyah.', 3);

-- =====================================================
-- Table 7: halaman_statis
-- Static page contents (sejarah, visi misi, sambutan)
-- =====================================================
CREATE TABLE halaman_statis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(50) NOT NULL UNIQUE,
    judul VARCHAR(200) NOT NULL,
    konten LONGTEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data halaman statis
INSERT INTO halaman_statis (slug, judul, konten) VALUES
('sejarah', 'Sejarah SDIT Umar Bin Khattab Kudus', '<p>SDIT Umar Bin Khattab Kudus didirikan pada tahun 2010 di bawah naungan <strong>Yayasan Al-Fath</strong> dengan tujuan mencetak generasi Qur\'ani yang berakhlak mulia dan unggul dalam prestasi.</p><p>Berawal dari 2 rombongan belajar dengan 40 siswa, kini SDIT UBK telah berkembang menjadi sekolah dengan 12 rombongan belajar dan lebih dari 300 siswa aktif.</p><p>Sekolah yang berlokasi strategis di pusat Kota Kudus ini dilengkapi dengan fasilitas modern seperti ruang kelas ber-AC, laboratorium komputer, perpustakaan digital, dan masjid yang nyaman untuk kegiatan ibadah siswa.</p>'),
('visi_misi', 'Visi & Misi SDIT Umar Bin Khattab', '<h3>VISI</h3><p>"Menjadi Sekolah Dasar Islam Terpadu yang unggul dalam prestasi, kuat dalam akidah, dan berakhlak mulia berdasarkan Al-Qur\'an dan As-Sunnah"</p><h3>MISI</h3><ol><li>Menyelenggarakan pendidikan Islam terpadu yang mengintegrasikan ilmu pengetahuan umum dan agama</li><li>Membentuk generasi Qur\'ani melalui program tahfidz Al-Qur\'an</li><li>Mengembangkan potensi akademik dan non-akademik siswa secara optimal</li><li>Menanamkan nilai-nilai akhlak mulia dalam kehidupan sehari-hari</li><li>Menciptakan lingkungan sekolah yang Islami, nyaman, dan kondusif untuk belajar</li></ol>'),
('sambutan', 'Sambutan Kepala Sekolah', '<div style="text-align: center; margin-bottom: 20px;"><em>"Assalamu\'alaikum Warahmatullahi Wabarakatuh"</em></div><p>Alhamdulillahi rabbil \'alamin, segala puji bagi Allah SWT yang telah memberikan rahmat dan hidayah-Nya kepada kita semua.</p><p>Selamat datang di website resmi <strong>SDIT Umar Bin Khattab Kudus</strong>. Kami berkomitmen untuk memberikan pendidikan terbaik yang mengintegrasikan nilai-nilai Islam dengan ilmu pengetahuan modern.</p><p>Di SDIT UBK, kami tidak hanya fokus pada prestasi akademik, tetapi juga pembentukan karakter Islami yang kuat. Melalui program tahfidz, pembelajaran berbasis STEM, dan berbagai kegiatan ekstrakurikuler, kami berupaya mencetak generasi yang cerdas, beriman, dan berakhlak mulia.</p><p>Semoga website ini dapat menjadi jembatan komunikasi antara sekolah dengan orang tua, masyarakat, dan seluruh stakeholder pendidikan. Mari bersama-sama kita wujudkan generasi Qur\'ani yang gemilang.</p><div style="margin-top: 30px;"><strong>Wassalamu\'alaikum Warahmatullahi Wabarakatuh</strong><br><br><strong>Ustadz Ahmad Fauzi, S.Pd.I</strong><br>Kepala Sekolah SDIT Umar Bin Khattab Kudus</div>');

-- =====================================================
-- Table 8: ppdb
-- Admission applications (Penerimaan Peserta Didik Baru)
-- =====================================================
CREATE TABLE ppdb (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_siswa VARCHAR(100) NOT NULL,
    tempat_lahir VARCHAR(100) NOT NULL,
    tanggal_lahir DATE NOT NULL,
    jenis_kelamin ENUM('L', 'P') NOT NULL,
    alamat TEXT NOT NULL,
    nama_ayah VARCHAR(100) NOT NULL,
    nama_ibu VARCHAR(100) NOT NULL,
    no_hp VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    dokumen_akta VARCHAR(255) DEFAULT NULL,
    dokumen_kk VARCHAR(255) DEFAULT NULL,
    foto_siswa VARCHAR(255) DEFAULT NULL,
    status ENUM('pending', 'lolos', 'tidak_lolos') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data PPDB (2 sample applications)
INSERT INTO ppdb (nama_siswa, tempat_lahir, tanggal_lahir, jenis_kelamin, alamat, nama_ayah, nama_ibu, no_hp, email, status) VALUES
('Muhammad Fahri Ramadhan', 'Kudus', '2019-05-15', 'L', 'Jl. Sunan Kudus No. 45, Kudus', 'Ahmad Sulaiman', 'Siti Maryam', '08123456789', 'ahmad.sulaiman@email.com', 'lolos'),
('Zahra Amelia Putri', 'Kudus', '2019-08-22', 'P', 'Jl. Singocandi No. 12, Kudus', 'Muhammad Hasan', 'Fatimah Azzahra', '08129876543', 'muh.hasan@email.com', 'pending');

-- =====================================================
-- Table 9: kontak
-- Contact messages from website visitors
-- =====================================================
CREATE TABLE kontak (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telepon VARCHAR(20),
    pesan TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_is_read (is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data kontak (3 sample messages)
INSERT INTO kontak (nama, email, telepon, pesan, is_read) VALUES
('Budi Santoso', 'budi.santoso@email.com', '081234567890', 'Assalamu\'alaikum, saya ingin menanyakan biaya pendaftaran dan SPP untuk tahun ajaran 2026/2027. Terima kasih.', TRUE),
('Dewi Lestari', 'dewi.lestari@email.com', '085678901234', 'Apakah SDIT UBK menerima siswa pindahan dari sekolah lain? Anak saya saat ini kelas 3 SD.', FALSE),
('Rudi Hartono', 'rudi.hartono@email.com', '089876543210', 'Mohon info jadwal open house dan pendaftaran gelombang 2. Jazakumullahu khairan.', FALSE);

-- =====================================================
-- Table 10: konfigurasi
-- Site configuration settings
-- =====================================================
CREATE TABLE konfigurasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(50) NOT NULL UNIQUE,
    `value` TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_key (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert configuration data
INSERT INTO konfigurasi (`key`, `value`) VALUES
('ppdb_status', 'open'),
('sekolah_alamat', 'Jl. Sunan Muria No. 123, Kudus, Jawa Tengah 59319'),
('sekolah_telepon', '(0291) 438888'),
('sekolah_email', 'info@sdit-ubk.sch.id'),
('sekolah_jam_operasional', 'Senin - Jumat: 07.00 - 15.00 WIB<br>Sabtu: 07.00 - 12.00 WIB'),
('social_facebook', 'https://facebook.com/sditubkkudus'),
('social_instagram', 'https://instagram.com/sditubkkudus'),
('social_youtube', 'https://youtube.com/@sditubkkudus'),
('logo_path', 'uploads/config/logo.png');

-- =====================================================
-- Table 11: sessions
-- Session management untuk admin
-- =====================================================
CREATE TABLE sessions (
    id VARCHAR(128) PRIMARY KEY,
    admin_id INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    user_agent VARCHAR(255),
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE,
    INDEX idx_admin_id (admin_id),
    INDEX idx_last_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- END OF DATABASE SCHEMA
-- =====================================================
